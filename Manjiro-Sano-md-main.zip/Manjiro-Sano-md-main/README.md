# Manjiro Sano md*

<p align="center">
  <a href="https://github.com/Cod3Uchiha">
    <img alt="Manjiro-Sano-md" height="400" src="https://telegra.ph/file/2645fb9536dad7eda6aee.jpg">
  </a>
</p>

***
<p align="center">
<a href="https://github.com/Cod3Uchiha?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/Cod3Uchiha?label=Followers&style=social"></a>
<a href="https://github.com/Cod3Uchiha/Manjiro-Sano-md/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/Cod3Uchiha/Manjiro-Sano-md?&style=social"></a>
<a href="https://github.com/Cod3Uchiha/Manjiro-Sano-md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Cod3Uchiha/Manjiro-Sano-md?style=social"></a>
<a href="https://github.com/Cod3Uchiha/Manjiro-Sano-md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Cod3Uchiha/Manjiro-Sano-md?label=Watching&style=social"></a>
  
***

# *_GET • [SESSION ID](https://bot-by-umar-d2b1b3360401.herokuapp.com) • FOR Manjiro Sano md_*
for now use the Gold bot scanner

***

# *_NOW • [DEPLOY](https://dashboard.heroku.com/new?button-url=https://github.com/Cod3Uchiha/Manjiro-Sano-md&template=https://github.com/Cod3Uchiha/Manjiro-Sano-md) • Manjiro Sano md ON HEROKU_*

***

# *_FOLLOW • [WHATSAPP CHANNEL](https://whatsapp.com/channel/0029VaKjSra9WtC0kuJqvl0g) •_*

***

# *_DEVELOPER_*
<a href="https://github.com/Cod3Uchiha"><img src="https://telegra.ph/file/7d1d362a15f946d427db1.jpg" width="250" height="250" alt="Cod3Uchiha"/></a>
# _=> • [Cod3Uchiha](https://github.com/Cod3Uchiha) • <=_

# *_Acknowledgements_*

# I would like to extend my sincere thanks to D4X-UMAR • https://github.com/D4X-UMAR for providing the base of the bot. His contributions have been instrumental in the development of this project.

# Thank you, D4X-UMAR • https://github.com/D4X-UMAR for your valuable input and support!
