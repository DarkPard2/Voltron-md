
/** 

🇫‌🇱‌🇦‌🇸‌🇭‌-🇲‌🇩‌ 

  𝗖𝗼𝗽𝘆𝗿𝗶𝗴𝗵𝘁 (𝗖) 2024.
 𝗟𝗶𝗰𝗲𝗻𝘀𝗲𝗱 𝘂𝗻𝗱𝗲𝗿 𝘁𝗵𝗲  𝗠𝗜𝗧 𝗟𝗶𝗰𝗲𝗻𝘀𝗲;
 𝗬𝗼𝘂 𝗺𝗮𝘆 𝗻𝗼𝘁 𝘂𝘀𝗲 𝘁𝗵𝗶𝘀 𝗳𝗶𝗹𝗲 𝗲𝘅𝗰𝗲𝗽𝘁 𝗶𝗻 𝗰𝗼𝗺𝗽𝗹𝗶𝗮𝗻𝗰𝗲 𝘄𝗶𝘁𝗵 𝘁𝗵𝗲 𝗟𝗶𝗰𝗲𝗻𝘀𝗲.
 𝗜𝘁 𝗶𝘀 𝘀𝘂𝗽𝗽𝗹𝗶𝗲𝗱 𝗶𝗻 𝘁𝗵𝗲 𝗵𝗼𝗽𝗲 𝘁𝗵𝗮𝘁 𝗶𝘁 𝗺𝗮𝘆 𝗯𝗲 𝘂𝘀𝗲𝗳𝘂𝗹.
 * @𝗽𝗿𝗼𝗷𝗲𝗰𝘁_𝗻𝗮𝗺𝗲 : 𝗙𝗹𝗮𝘀𝗵 𝗠𝗗, 𝗮 𝘀𝗶𝗺𝗽𝗹𝗲 𝗮𝗻𝗱 𝗲𝗮𝘀𝘆 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝘂𝘀𝗲𝗿 𝗯𝗼𝘁 
 * @𝗼𝘄𝗻𝗲𝗿: 𝗙𝗿𝗮𝗻𝗰𝗲 𝗞𝗶𝗻𝗴 
 
 **/
























const _0x12f5a2=_0x1608;(function(_0x4b1645,_0x280fa1){const _0x421128=_0x1608,_0x27e5ca=_0x4b1645();while(!![]){try{const _0x580932=parseInt(_0x421128(0x191))/0x1*(-parseInt(_0x421128(0x1b4))/0x2)+-parseInt(_0x421128(0x1b2))/0x3*(parseInt(_0x421128(0x1a5))/0x4)+-parseInt(_0x421128(0x19f))/0x5+-parseInt(_0x421128(0x19e))/0x6*(-parseInt(_0x421128(0x1b1))/0x7)+-parseInt(_0x421128(0x1a9))/0x8*(parseInt(_0x421128(0x1a4))/0x9)+-parseInt(_0x421128(0x1a6))/0xa*(-parseInt(_0x421128(0x1b0))/0xb)+-parseInt(_0x421128(0x196))/0xc*(-parseInt(_0x421128(0x19c))/0xd);if(_0x580932===_0x280fa1)break;else _0x27e5ca['push'](_0x27e5ca['shift']());}catch(_0x1b17f2){_0x27e5ca['push'](_0x27e5ca['shift']());}}}(_0x35fd,0xd079a));function _0x1608(_0x22777a,_0x262bbf){const _0x35fd9d=_0x35fd();return _0x1608=function(_0x1608e8,_0xcd9969){_0x1608e8=_0x1608e8-0x190;let _0x333119=_0x35fd9d[_0x1608e8];return _0x333119;},_0x1608(_0x22777a,_0x262bbf);}const {france}=require(_0x12f5a2(0x1ad)),axios=require(_0x12f5a2(0x1a3)),Genius=require('genius-lyrics'),Client=new Genius[(_0x12f5a2(0x1a2))](_0x12f5a2(0x1aa));france({'nomCom':_0x12f5a2(0x1ab),'reaction':'🔰','categorie':'General'},async(_0x30be79,_0x224c18,_0x36b620)=>{const _0x372a4d=_0x12f5a2,{repondre:_0x2b7338,arg:_0x477cdf,ms:_0x20f7ae}=_0x36b620,_0x388eb9=_0x477cdf[_0x372a4d(0x1b6)]('\x20');let [_0x424537,_0x22a748]=_0x388eb9[_0x372a4d(0x1b9)]('/');if(_0x388eb9['split']('/')<0x2)return _0x2b7338(_0x372a4d(0x1ac));let _0x1d7f27=[];for(let _0x43746a of _0x22a748[_0x372a4d(0x1b9)](',')){_0x1d7f27['push'](_0x43746a);}await _0x224c18['sendMessage'](_0x30be79,{'poll':{'name':_0x424537,'values':_0x1d7f27}});}),france({'nomCom':_0x12f5a2(0x1b7),'reaction':'📀','categorie':_0x12f5a2(0x1bb)},async(_0x3c9a53,_0x429468,_0x2e08cc)=>{const _0x194c57=_0x12f5a2,{repondre:_0x39d38c,arg:_0x14a129,ms:_0x12fa8e}=_0x2e08cc,_0x277864=await fetch('https://nekos.life/api/v2/fact'),_0x29b4fc=await _0x277864[_0x194c57(0x1a1)]();_0x39d38c('◆━━━━━━⚙️FACT⚙️━━━━━━◆\x20\x20\x0a*🤖*\x20'+_0x29b4fc['fact']+_0x194c57(0x194));}),france({'nomCom':_0x12f5a2(0x1b5),'reaction':'🔰','categorie':_0x12f5a2(0x1bb)},async(_0x17a7fa,_0x2c6ea2,_0x150380)=>{const _0x4116af=_0x12f5a2,{repondre:_0x56d07e,arg:_0x58a7c1,ms:_0x35be98}=_0x150380,_0x2ae9e4=await fetch('https://favqs.com/api/qotd'),_0x25792f=await _0x2ae9e4['json'](),_0x720284=_0x4116af(0x1a7)+_0x25792f[_0x4116af(0x19b)][_0x4116af(0x1ba)]+_0x4116af(0x199)+_0x25792f[_0x4116af(0x19b)]['author']+_0x4116af(0x195);_0x56d07e(_0x720284);}),france({'nomCom':'define','reaction':'🔰','categorie':'Search'},async(_0x256543,_0xc1d6f6,_0x164f4f)=>{const _0x358d42=_0x12f5a2,{repondre:_0xa66f30,arg:_0x209101,ms:_0x36568a}=_0x164f4f;if(!_0x209101||_0x209101[_0x358d42(0x1a0)]===0x0)return _0xa66f30('Mujhe\x20information\x20do');const _0x2e458b=_0x209101['join']('\x20');try{let {data:_0x17a530}=await axios['get'](_0x358d42(0x19d)+_0x2e458b);var _0x7e1ec4='\x0a\x20Word:\x20'+_0x2e458b+_0x358d42(0x1af)+_0x17a530[_0x358d42(0x1b8)][0x0][_0x358d42(0x198)][_0x358d42(0x193)](/\[/g,'')['replace'](/\]/g,'')+'\x0a\x20Ese\x20Likho:\x20'+_0x17a530['list'][0x0][_0x358d42(0x190)]['replace'](/\[/g,'')['replace'](/\]/g,'');return _0xa66f30(_0x7e1ec4);}catch{return _0xa66f30('Koi\x20result\x20nahi\x20iska\x20'+_0x2e458b);}}),france({'nomCom':_0x12f5a2(0x19a),'reaction':'🔰','categorie':_0x12f5a2(0x1ae)},async(_0x253ce4,_0x2e59af,_0x15158b)=>{const _0xdc27f3=_0x12f5a2,{repondre:_0x56a379,arg:_0x3c26ec,ms:_0x134416}=_0x15158b;try{if(!_0x3c26ec||_0x3c26ec[_0xdc27f3(0x1a0)]===0x0)return _0x56a379(_0xdc27f3(0x192));const _0x65ba71=_0x3c26ec[_0xdc27f3(0x1b6)]('\x20'),_0x5500be=await Client['songs'][_0xdc27f3(0x1a8)](_0x65ba71),_0x524cb3=_0x5500be[0x0],_0x3be5d3=await _0x524cb3[_0xdc27f3(0x19a)]();await _0x2e59af[_0xdc27f3(0x1bc)](_0x253ce4,{'text':_0x3be5d3},{'quoted':_0x134416});}catch(_0x246603){reply('Mujhe\x20is\x20ka\x20koi\x20result\x20nahi\x20mila\x20'+text+_0xdc27f3(0x197)),console[_0xdc27f3(0x1b3)](_0x246603);}});function _0x35fd(){const _0x5a4731=['2616336HfEOxp','4208884DsfIIJ','4083350LIdBLM','\x0a◆━━━━━━⚙️QUOTE⚙️━━━━━━◆\x20\x0a◇\x20_','search','32PkpyyF','jKTbbU-6X2B9yWWl-KOm7Mh3_Z6hQsgE4mmvwV3P3Qe7oNa9-hsrLxQV5l5FiAZO','poll','Apne\x20Galat\x20Likha.\x0aEse\x20Likho:\x20poll\x20Yeh\x20kia\x201+1/2,\x203,\x204','../framework/france','Search','\x0a\x20Definition:\x20','33LOSvgf','7kWACYh','3HUnEIt','log','658872bCmOCt','quotes','join','fact','list','split','body','User','sendMessage','example','2PVxYfl','Mujhe\x20kisi\x20song\x20ka\x20name\x20batao','replace','\x0a\x0a\x0a\x0a\x0a*💻*\x20MADE\x20BY\x20*GOLD-MD*\x0a\x0a╔═════⚙️\x0a║🔰\x20*Manjiro-Sano-md\x20WHATSAPP\x20BOT*\x0a╚════════════════════>\x20\x20','\x0a\x0a\x0a\x0a\x0a⚔️\x20_MADE\x20BY:_\x20*UMAR*\x0a\x0a\x0a╔═════💻\x0a║⚔️\x20*GOLD-MD\x20WHATSAPP\x20BOT*\x0a╚════════════════════>\x20','684ViUyoL','.\x20Song\x20search\x20ho\x20raha\x20hai.','definition','_\x0a\x0a\x0a◇\x20*AUTHOR:*\x20','lyrics','quote','629382bCVfgb','http://api.urbandictionary.com/v0/define?term=','2894394zJYRir','3695895PgilLE','length','json','Client','axios'];_0x35fd=function(){return _0x5a4731;};return _0x35fd();}
